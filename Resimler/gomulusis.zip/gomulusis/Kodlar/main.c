#include <main.h>

#define buttondurdurma input(pin_a4)
#define buttondegistir input(pin_a5)
#define buttonartirma input(pin_e0)
#define buttonazaltma input(pin_e1)

int milisaniyesayici = 0;
int saniye = 0;
int dakika = 0;
int saat = 0;
int durdur = 0;
int saniyeStep1 = 0, saniyeStep2 = 0;
int dakikaStep1 = 0, dakikaStep2 = 0;
int saatStep1 = 0, saatStep2 = 0;
int saatal=255, dakikaal=255, saniyeal=255, alarmsaat=254, alarmdakika=254, alarmsaniye=254;
#int_timer1

void timer1()
{
   
   if(durdur == 0)
   {
      milisaniyesayici++;
   if(milisaniyesayici == 10)
   {
      milisaniyesayici = 0;
      saniye++;
   
      if(saniye == 60)
      {
         saniye = 0;
         dakika++;
      
         if(dakika == 60)
         {
         dakika = 0;
         saat++;
         
            if(saat == 24)
            {
               saat = 0;
            }
         }
      }   
   }
   output_a(milisaniyesayici);
   
   saniyeStep1 = saniye % 10;
   saniyeStep2 = (saniye / 10 ) % 10;
   output_b(saniyeStep1 | saniyeStep2 << 4);
   
   dakikaStep1 = dakika % 10;
   dakikaStep2 = (dakika / 10) % 10;
   output_c(dakikaStep1 | dakikaStep2 << 4);
   
   saatStep1 = saat % 10;
   saatStep2 = (saat / 10) % 10;
   output_d(saatStep1 | saatStep2 << 4);
   }
}

void main()
{
   setup_timer_1(T1_INTERNAL | T1_DIV_BY_8);
   enable_interrupts(int_timer1);
   enable_interrupts(global);
   int i=0;
   
   while(TRUE)
   {     
      if(buttondurdurma == 1){
      saatal = saat;
      dakikaal = dakika;
      saniyeal = saniye;
      durdur = 1;
      delay_ms(500);
      }
      while(durdur==1){
         if(buttondurdurma==1){
            alarmsaat=saat;
            alarmdakika=dakika;
            alarmsaniye=saniye;
            delay_ms(500);
            saat=saatal;
            dakika=dakikaal;
            saniye=saniyeal;
   
            saniyeStep1 = saniye % 10;
            saniyeStep2 = (saniye / 10 ) % 10;
            output_b(saniyeStep1 | saniyeStep2 << 4);
   
            dakikaStep1 = dakika % 10;
            dakikaStep2 = (dakika / 10) % 10;
            output_c(dakikaStep1 | dakikaStep2 << 4);
         
            saatStep1 = saat % 10;
            saatStep2 = (saat / 10) % 10;
            output_d(saatStep1 | saatStep2 << 4);
            durdur=0;
            delay_ms(500);
            break;
         }
         if(buttondegistir==1){
            i++;
            delay_ms(500);
            if(i==3){
               i=0;
            }
         }
         if(buttonartirma==1){
            if(i==0){
               saniye++;
               if(saniye==60){
               saniye=0;
               dakika++;
               if(dakika==60){
                  dakika=0;
                  saat++;
                  if(saat==24){
                     saat=0;
                  }
               } 
            }
         }
            else if(i==1){
            dakika++;
            if(dakika==60){
               dakika=0;
               saat++;
               if(saat==24){
                  saat=0;
                  }
               }
            }
            else if(i==2)
            {
               saat++;
               if(saat==24)
               {
                  saat=0;
               }
            }
         saniyeStep1 = saniye % 10;
         saniyeStep2 = (saniye / 10 ) % 10;
         output_b(saniyeStep1 | saniyeStep2 << 4);
   
         dakikaStep1 = dakika % 10;
         dakikaStep2 = (dakika / 10) % 10;
         output_c(dakikaStep1 | dakikaStep2 << 4);
   
         saatStep1 = saat % 10;
         saatStep2 = (saat / 10) % 10;
         output_d(saatStep1 | saatStep2 << 4);
         delay_ms(500);
         }
         
         if(buttonazaltma==1){
            if(i==0){
            saniye--;
            if(saniye==-1){
               saniye=59;
               dakika++;
               if(dakika==-1){
                  dakika=59;
                  saat--;
                  if(saat==-1){
                     saat=23;
                  }
               }
            }
         }
         else if(i==1){
                  dakika--;
                  if(dakika==-1){
                     dakika=59;
                     saat--;
                     if(saat==-1){
                        saat=23;
                     }
                  }
               }
         else if(i==2){
                  saat--;
                  if(saat==-1){
                     saat=23;
                  }
            }
         saniyeStep1 = saniye % 10;
         saniyeStep2 = (saniye / 10 ) % 10;
         output_b(saniyeStep1 | saniyeStep2 << 4);
   
         dakikaStep1 = dakika % 10;
         dakikaStep2 = (dakika / 10) % 10;
         output_c(dakikaStep1 | dakikaStep2 << 4);
   
         saatStep1 = saat % 10;
         saatStep2 = (saat / 10) % 10;
         output_d(saatStep1 | saatStep2 << 4);
         delay_ms(500);
         }
      }
      if(alarmsaat==saat && alarmdakika==dakika && alarmsaniye==saniye)
      {
         output_high(PIN_E2);
      }
      else{
        output_low(PIN_E2);
       
      }
   }
}


